#!/usr/bin/python3

import complejo

c1 = complejo.Complejo(img=1,real=2)
c2 = complejo.Complejo()

complejo.setReal(c2,21)
complejo.setImg(c2,325.96)
complejo.setSign(c2, False)

print(complejo.getReal(c1))
print(complejo.getImg(c1))
print(complejo.getSign(c1))
print(c2)
