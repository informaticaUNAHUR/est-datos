#!/usr/bin/python3

import lista

l = lista.Lista()

lista.append(l,1)
lista.append(l,2)
lista.append(l,3)

lista.mostrar(l)
