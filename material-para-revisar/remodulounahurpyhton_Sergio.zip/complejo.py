#!/usr/bin/python3

from struct import *

Complejo = Struct("Complejo", real = 0, img = 0, sign = True)

def getReal(c):
    return c.real

def getImg(c):
    return c.img

def getSign(c):
    return c.sign

def setReal(c, r):
    c.real = r

def setImg(c, i):
    c.img = i

def setSign(c, s):
    c.sign = s
