#!/usr/bin/python3

from namedlist import namedlist

def Struct(structname, **kwargs):
    variables = []
    for key,value in kwargs.items():
        variables.append((key,value))
    struct = namedlist(structname, variables)
    return struct
