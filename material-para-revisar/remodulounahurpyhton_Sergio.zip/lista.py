#!/usr/bin/python3

from struct import *

##############Estructura NodoLista######################
NodoLista = Struct("NodoLista", data = None, sig = None)

def getData(nodo):
    return nodo.data

def getSig(nodo):
    return nodo.sig

def setData(nodo,data):
    nodo.data = data

def setSig(nodo,sig):
    nodo.sig = sig
########################################################

##################Estructura Lista######################
Lista = Struct("Lista", primero = None)

def append(lista, data):
    nuevo = NodoLista(data=data)
    if lista.primero == None:
        lista.primero = nuevo
    else:
        actual = lista.primero
        while getSig(actual) != None:
            actual = getSig(actual)
        setSig(actual,nuevo)

def mostrar(lista):
    actual = lista.primero
    while getSig(actual) != None:
        print(getData(actual),"-> ",end="")
        actual = getSig(actual)
    print(getData(actual),"-|")
########################################################
