from unahur import *

(variant('Dias')
    .option('Lunes')
    .option('Martes')
    .option('Miercoles')
    .option('Jueves')
    .option('Viernes')
    .option('Sabado')
    .option('Domingo')
.define())

print (Lunes == Martes)
print (Miercoles)

(record('Punto')
    .field('x')
    .field('y')
.define())

(record('Punto3D')
    .field('x')
    .field('y')
    .field('z')
.define())

p2 = Punto3D(x = 1, y = 2, z = 4)
print(p2)

p = Punto(x = 1, y = 4)
print(p)

ls = [1,2,3,4]
els = []

print(es_vacia(ls))
print(es_vacia(els))

print(primero(ls))

print(sin_primero(ls))

print(agregar_delante(ls, 5))

print(ls)

Sin_Primero(ls)
print(ls)

Agregar_Delante(ls, 1)
Agregar_Detras(ls, 5)
print(ls)


