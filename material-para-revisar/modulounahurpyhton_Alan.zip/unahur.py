import enum
import inspect
import sys

class __InvalidDefinitionException__(Exception):
    pass

class __InvalidAccessException__(Exception):
    pass

class __VariantTypeBuilder__(object):
    def __init__(self, name, mod, modname):
        self.name = name
        self.mod = mod
        self.modname = modname
        self.options = []
    def option(self, option):
        self.options.append(option)
        return self
    def define(self):
        self.validate()
        module_data = { val : idx for idx, val in enumerate(self.options)}
        def _inner_repr_(this):
            return this.name
        module_data['__repr__'] = _inner_repr_
        newenum = enum.Enum(self.name, module_data)
        self.mod.__dict__[self.name] = newenum
        for val in self.options:
            self.mod.__dict__[val] = newenum[val]
        return newenum
    def validate(self):
        if self.name in self.mod.__dict__:
            raise __InvalidDefinitionException__('Ya existe un tipo definido con el nombre "' + self.name + '". Verifique sus definiciones.')
        for option in self.options:
            if option in self.mod.__dict__:
                raise __InvalidDefinitionException__('Ya existe un tipo definido con el nombre "' + option + '" o un tipo variant que define la misma opción. Verifique sus definiciones.')

class __RecordTypeBuilder__(object):
    def __init__(self, name, mod, modname):
        self.name = name
        self.mod = mod
        self.modname = modname
        self.fields = []
    def field(self, field):
        self.fields.append(field)
        return self
    def define(self):
        self.validate()
        module_data = { val : None for val in self.fields}
        def _inner_repr_(this):
            return this.__class__.__name__ + repr(this.__dict__)
        module_data['__repr__'] = _inner_repr_
        def _inner_init_(this, **kwargs):
            valids = this.__fields__()
            for val, key in enumerate(kwargs):
                if key not in valids:
                    raise __InvalidDefinitionException__('La definición de "' + this.__class__.__name__ + '" no declara el campo "' + key + '".El campo es inválido al construir el registro.')
                setattr(this, key, val)
            for val in valids:
                if val not in kwargs:
                    raise __InvalidDefinitionException__('La construcción del registro "' + this.__class__.__name__ + '" es incorrecta. Falta el campo "' + val + '" al definir el registro')
        module_data['__init__'] = _inner_init_
        def __fields__(cls):
            return self.fields
        module_data['__fields__'] = __fields__
        newtype = type(self.name, (object,), module_data)
        self.mod.__dict__[self.name] = newtype
        return newtype
    def validate(self):
        if self.name in self.mod.__dict__:
            raise __InvalidDefinitionException__('Ya existe un tipo definido con el nombre "' + self.name + '". Verifique sus definiciones.')

def variant(name):
    modname = inspect.getmodule(inspect.stack()[1][0]).__name__
    mod = sys.modules[modname]
    return __VariantTypeBuilder__(name, mod, modname)

def record(name):
    modname = inspect.getmodule(inspect.stack()[1][0]).__name__
    mod = sys.modules[modname]
    return __RecordTypeBuilder__(name, mod, modname)

def es_vacia(lista):
    return len(lista) == 0

def primero(lista):
    if len(lista) == 0:
        raise __InvalidAccessException__('No se puede pedir el primero, la lista está vacía.')
    return lista[0]

def sin_primero(lista):
    if len(lista) == 0:
        raise __InvalidAccessException__('No se puede pedir el sin_primero, la lista está vacía.')
    return lista[1:]

def agregar_detras(lista, elemento):
    return lista + [elemento]

def agregar_delante(lista, elemento):
    return [elemento] + lista

def Sin_Primero(lista):
    if len(lista) == 0:
        raise __InvalidAccessException__('No se puede pedir el sin_primero, la lista está vacía.')
    del lista[0]

def Agregar_Detras(lista, elemento):
    return lista.append(elemento)

def Agregar_Delante(lista, elemento):
    return lista.insert(0, elemento)